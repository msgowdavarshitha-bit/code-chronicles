L=[10,"rama",10.5,20,30]
print(L)                    #[10, 'rama', 10.5, 20, 30]
print(len(L))               #5
print(type(L))              #<class 'list'>
print(L[1])                 #rama