try:
    a=int(input("Enter a num1:"))
    b=int(input("Enter a num2:"))
    c=a/b
    print(c)
 
except ValueError as e:
    print("Its a ValueError")   
except ZeroDivisionError as e:
    print("Cannot divide a number by zero")
except Exception as e:
    print("Its a Error")
    
print("="*30)

balance=10000
try: 
    amount=int(input("Enter the amount to withdrawed:"))
except ValueError as e:
    print("Invalid input")
except Exception as e:
    print

# print("="*30)



# print("="*30)



# print("="*30)



# print("="*30)