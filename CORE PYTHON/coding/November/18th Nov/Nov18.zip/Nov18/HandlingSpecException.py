try:
    a=int(input("Enter a num:"))
    b=int(input("Enter a num:"))
    c=a/b
    print(c)
 
except ValueError as e:
    print("Its a ValueError")   
except ZeroDivisionError as e:
    print("Its a ZDE")
except Exception as e:
    print("Its a Error")
    
# Enter a num:10
# Enter a num:five
# Its a ValueError

# Enter a num:10
# Enter a num:0
# Its a ZDE