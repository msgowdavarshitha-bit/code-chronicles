class OS:
    def __init__(self):
        self.status=True
        print("OS is installing")
        print("OS is still installing")
        
    def getOS(self):
        print("OS is installed")
        
class Mobile:
    def __init__(self,name):
        self.mname=name
        self.o=OS()
        print("Mobile is created")
        print("With OS installed")
        
m=Mobile("iphone")          #OS is installing
                            #OS is still installing
                            #Mobile is created
                            #With OS installed

print(m.mname)          #iphone
print(m.o.status)       #True
m.o.getOS()             #OS is installed

del m

print(m.o.status)           #NameError: name 'm' is not defined