class Charger:
    def __init__(self,name):
        self.cname=name
        print("Charger is ready")
        
    def getCharger(self):
        print("Charger is ready to connect")
        
class Mobile:
    def __init__(self,name):
        self.mname=name
        self.c1=""
        print("Mobile is ready")
        
    def hasMobile(self,c):
        self.c1=c
        print("Both are ready to connect")
        
m=Mobile("iphone")                      #Mobile is ready
charge=Charger("iph.charger")           #Charger is ready

print(m.mname)                  #iphone
m.hasMobile(charge)             #Both are ready to connect
print(m.c1.cname)               #iph.charger
m.c1.getCharger()               #Charger is ready to connect

del m

print(charge.cname)             #iph.charger
charge.getCharger()             #Charger is ready to connect