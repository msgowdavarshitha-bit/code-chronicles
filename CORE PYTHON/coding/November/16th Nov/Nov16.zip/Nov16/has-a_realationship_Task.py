class Teacher:
    def __init__(self, teacher_name, subject):
        self.teacher_name = teacher_name
        self.subject = subject

class Department:
    def __init__(self, department_name, teacher):
        self.department_name = department_name
        self.teacher = teacher

    def display_department(self):
        print("Department:", self.department_name)
        print("Teacher:", self.teacher.teacher_name)
        print("Subject:", self.teacher.subject)

t1 = Teacher("Rahul", "Python")
d1 = Department("Computer Science", t1)

d1.display_department()

del Department

print(t1.teacher_name)
print(t1.subject)

print("="*30)

class Engine:
    def __init__(self, engine_type, horsepower):
        self.engine_type = engine_type
        self.horsepower = horsepower

class Car:
    def __init__(self, brand, model):
        self.brand = brand
        self.model = model
        self.engine = Engine("Petrol", 150)

    def display_car(self):
        print("Brand:", self.brand)
        print("Model:", self.model)
        print("Engine Type:", self.engine.engine_type)
        print("Horsepower:", self.engine.horsepower)

c1 = Car("Toyota", "Innova")
c1.display_car()

print("="*30)

class Course:
    def __init__(self, course_name, duration):
        self.course_name = course_name
        self.duration = duration

class Student:
    def __init__(self, student_name, student_id, course):
        self.student_name = student_name
        self.student_id = student_id
        self.course = course

    def display_student(self):
        print("Student Name:", self.student_name)
        print("Student ID:", self.student_id)
        print("Course:", self.course.course_name)
        print("Duration:", self.course.duration)

c1 = Course("Python Programming", "3 Months")
s1 = Student("Arun", 101, c1)

s1.display_student()

print("="*30)

print("="*30)

print("="*30)

print("="*30)

print("="*30)

print("="*30)

print("="*30)

print("="*30)