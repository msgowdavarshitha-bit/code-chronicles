class Car:
    def __init__(self,name):
        self.cname=name
        print("Car is ready")
        
    def getCar(self):
        print("Car is moving")
        
class Heart:
    def __init__(self,name):
        self.hname=name
        print("Heart is present")
        
    def getHeart(self):
        print("Heart is beating")
        
class Person:
    def __init__(self,name):
        self.pname=name
        self.h=Heart("Rama.Heart")
        c1=""
        print("Person is ready")
        
    def hasPerson(self):
        print("Both are working")
        
p=Person("Rama")                #Heart is present
                                #Person is ready
car=Car("Tata")                 #Car is ready      

car.getCar()            #Car is moving
print(car.cname)            #Tata
p.h.getHeart()          #Heart is beating
print(p.h.hname)            #Rama.Heart
p.hasPerson()           #Both are working     
print(p.pname)              #Rama       
        