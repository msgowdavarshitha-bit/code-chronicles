#Using "raise"
def fun1():
    print("Entering fun1")
    try:
        fun2()
    except Exception as e:
        print("Error in fun1")
    print("Leaving fun1")
    
def fun2():
    print("Entering fun2")
    try:
        c=10/0
        print(c)
    except Exception as e:
        print("Error in fun2")
    raise e
    print("Leaving fun2")
    
print("Program started")
fun1()
print("Program ended")

# Program started
# Entering fun1
# Entering fun2
# Error in fun2
# Error in fun1
# Leaving fun1
# Program ended

print("="*30)

#Using "finally"
def fun1():
    print("Entering fun1")
    try:
        fun2()
    except Exception as e:
        print("Error in fun1")
        raise e
    finally:
        print("Leaving fun1")
    
def fun2():
    print("Entering fun2")
    try:
        c=10/0
        print(c)
    except Exception as e:
        print("Error in fun2")
        raise e
    finally:
        print("Leaving fun2")
    
print("Program started")
try:
    fun1()
except Exception as e:
    print("Error in main")
finally:
    print("Program ended")
    
# Program started
# Entering fun1
# Entering fun2
# Error in fun2
# Leaving fun2
# Error in fun1
# Leaving fun1
# Error in main
# Program ended
