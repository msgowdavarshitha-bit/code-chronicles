# a=int(input("Enter a n1:"))
# b=int(input("Enter a n2:"))
# c=a/b
# print(c)

# # Enter a n1:10
# # Enter a n2:5
# # 2.0

# # Enter a n1:10
# # Enter a n2:0
# # ZeroDivisionError: division by zero

a=int(input("Enter a n1:"))
b=int(input("Enter a n2:"))
try:
    c=a/b
    print(c)
except Exception as e:
    print("Error is occured")
    
# Enter a n1:10
# Enter a n2:0
# Error is occured

print("="*30)

def fun1():
    print("Entering fun1")
    try:
        fun2()
    except Exception as e:
        print("Error in fun1")
    print("Leaving fun1")
    
def fun2():
    print("Entering fun2")
    c=10/0
    print(c)
    print("Leaving fun2")
    
print("Program started")
fun1()
print("Program ended")

# Program started
# Entering fun1
# Entering fun2
# Error in fun1
# Leaving fun1
# Program ended

print("="*30)

def fun1():
    print("Entering fun1")
    try:
        fun2()
    except Exception as e:
        print("Error in fun1")
    print("Leaving fun1")
    
def fun2():
    print("Entering fun2")
    try:
        c=10/0
        print(c)
    except Exception as e:
        print("Error in fun2")
    print("Leaving fun2")
    
print("Program started")
fun1()
print("Program ended")

# Program started
# Entering fun1
# Entering fun2
# Error in fun2
# Leaving fun2
# Leaving fun1
# Program ended

print("="*30)

#Using "else"
try:
    a=int(input("Enter a num:"))
    b=int(input("Enter a num:"))
    c=a/b
    print(c)
    
except Exception as e:
    print("Its an error")
    
else:
    print("Excecuted")
    
# Enter a num:10
# Enter a num:5
# 2.0
# Excecuted