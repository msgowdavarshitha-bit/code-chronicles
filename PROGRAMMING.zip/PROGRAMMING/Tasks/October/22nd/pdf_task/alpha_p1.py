n=int(input("Enter: "))

for i in range(1,n+1):
    for j in range(1,i+1):
        print(chr(64+j),end=" ")
    print()



# Enter: 6
# A 
# A B 
# A B C 
# A B C D 
# A B C D E 
# A B C D E F 