n=int(input("Number: "))

for i in range(n,1-1,-1):
    for k in range(n,i,-1):
        print(" ",end="")
    for j in range(1,i+1):
        print("* ",end="")
    print()


print("==="*10)

for i in range(1,n+1):
    for k in range(n,i,-1):
        print(" ",end="")
    for i in range(1,i+1):
        print("* ",end="")
    print()