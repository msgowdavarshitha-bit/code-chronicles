n=int(input("ENter the number: "))

for i in range(1,n+1):
    for j in range(1,i+1):
        print(i,end="")
    print()

# ENter the number: 4
# 1
# 22
# 333
# 4444